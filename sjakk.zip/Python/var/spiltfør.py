import os
import json

current_script_dir = os.path.dirname(os.path.abspath(__file__))

python_dir = os.path.dirname(current_script_dir)

datafil_path = os.path.join(python_dir, "scripts", "spilt_før.json")

def _les_status():
    if os.path.exists(datafil_path):
        with open(datafil_path, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data.get("har_spilt", False)
    return False

har_spilt_før = _les_status()