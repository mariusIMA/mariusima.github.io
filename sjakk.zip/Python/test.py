print("Gi meg et tall.")
a = input()
try:
    a = int(a)
except:
    try:
        a = float(a)
    except:
        print("Du skrev ikke in integer eller desimaltall.")
        exit()
b = a * 10
print(b)

print("Gi meg to tall som skal multipliseres.")
c = input()
d = input()
try:
    c = int(c)
    d = int(d)
except:
    try:
        c = float(c)
        d = float(d)
    except:
        print("Du skrev ikke in integer eller desimaltall.")
        exit()
f = c * d
print(f)