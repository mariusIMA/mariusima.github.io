from sys import exit
import os
from var.spiltfør import har_spilt_før # Importer variabel
warningHaventPlayed = False
counter = 0
script_dir = os.path.dirname(os.path.abspath(__file__)) # Variabel som markerer hvor filen er i systemet
 
if har_spilt_før == True:
    print("Har spilt før") # Hvis denne gir True fortsetter programmet som normalt, ellers kommer warningHaventPlayed
else:
    warningHaventPlayed = True
 
while warningHaventPlayed:
    counter += 1
    if counter == 1:
        print("Error")
        print("Du har ikke fullført installasjonen enda! Åpne 'installer.bat' filen først for å fortsette med dette programmet. Skriv inn noe for å lukke programmet.")
        a = input()
        exit()
 
import pygame # Importere spillmodulen
print("Ikke lukk dette vinduet! Du kan minimere det da.")
status = "Fullscreen?"
pygame.display.set_caption(f"Sjakk - {status}") # Vises som tittelen på skjermen
 
# Pygame relaterte variabler
WIDTH, HEIGHT = 500, 500
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLACK = (0, 0, 0)
pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
 
# Font for tekst fra systemet
font = pygame.font.SysFont("Arial", 36, bold=False, italic=False)
smallfont = pygame.font.SysFont("Arial", 18, bold=False, italic=False)
 
# Generelle variabler
text = ""
feedback = "Fullscreen? (JA/NEI)"
fullscreen = True
main_menu = True
counter = 0
hmm = False
 
 
# Gameplay loop
while fullscreen:
    screen.fill(BLACK)
    for event in pygame.event.get(): # Sjekke inputt fra spilleren, og bruke det til ting som å lukke programmet når det signaliseres.
        if event.type == pygame.QUIT: # Hvis vi trykker X'en på pygame vinduet lukker det
            pygame.quit()
        elif event.type == pygame.KEYDOWN: # Sjekke om det registreres inputt
            if event.key == pygame.K_RETURN: # Enter tasten
                fullscreen_text = text
                if fullscreen_text.upper() == "JA":
                    import ctypes # Denne og de neste 4 neste linjene av kode er for å hente den faktiske skjermoppløsningen fra systemet så størrelsen blir korrekt
                    user32 = ctypes.windll.user32
                    user32.SetProcessDPIAware()
                    screen_width = user32.GetSystemMetrics(0)
                    screen_height = user32.GetSystemMetrics(1)
                    screen = pygame.display.set_mode((screen_width, screen_height))
                    text = ""
                    fullscreen = False # Skifte fra fullscreen til main menu
                    global is_fullscreen
                    is_fullscreen = True
                elif fullscreen_text.upper() == "NEI":
                    text = ""
                    fullscreen = False # Skifte fra fullscreen til main menu
                    is_fullscreen = False
                elif fullscreen_text.upper() == "FUH":
                    feedback = "ka feile deg?"
                    feedback_surface = font.render(feedback, True, WHITE)
                    screen.blit(feedback_surface, (25, 100))
                    pygame.display.flip()
                    import time
                    time.sleep(3)
                    fullscreen = False
                    hmm = True
                    text = ""
                    screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
                else:
                    feedback = "Kje våg å skriv noe dumt. Fullscreen? (JA/NEI)"
                    counter += 1
                    if counter > 1:
                        fullscreen = False
                        hmm = True
                        text = ""
                        screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
                    text = ""
            elif event.key == pygame.K_BACKSPACE: # tilbake tast
                text = text[:-1]
            else:
                text += event.unicode
    text_surface = font.render(text, True, WHITE) # Blitte alt til skjermen som teksten
    screen.blit(text_surface, (25, 50))
    feedback_surface = font.render(feedback, True, WHITE)
    screen.blit(feedback_surface, (25, 100))
    pygame.display.flip()
    clock.tick(60)
 
while hmm: # En 'straff' for hvis du gjør noe dumt
    import ctypes
    script_dir = os.path.dirname(os.path.abspath(__file__))
    image_path = os.path.join(script_dir, "media", "hmm.webp")
    hmmm = pygame.image.load(image_path).convert()
    user32 = ctypes.windll.user32 # Bruker disse fire OS komandoene for å finne breddn oh øyden
    user32.SetProcessDPIAware()  
    screen_width = user32.GetSystemMetrics(0)
    screen_height = user32.GetSystemMetrics(1)
    hmmm = pygame.transform.scale(hmmm, (screen_width, screen_height))
    screen.blit(hmmm, (0, 0))
    pygame.display.flip()
    clock.tick(60)
 
 
# Pygame variabler
info = pygame.display.Info()
WIDTH, HEIGHT = info.current_w, info.current_h
rect_singleplayer = pygame.rect.Rect((WIDTH / 2 - 105), (HEIGHT / 3), 200, 50) # Forsikre at plasseringen til rektangelet matcher skjermoppløsningen, varierer ofte
rect_multiplayer = pygame.rect.Rect((WIDTH / 2 - 105), (HEIGHT / 2), 200, 50)
text_single = "singleplayer"
text_multi = "multiplayer"
ORANGE = (255, 165, 0)
status = "Menu select"
 
 
while main_menu: # Finne ut om du vil spille singleplayer elle
    screen.fill(BLACK)
    for event in pygame.event.get(): # Sjekke inputt fra spilleren, og bruke det til ting som å lukke programmet når det signaliseres.
        if event.type == pygame.QUIT: # Hvis vi trykker X'en på pygame vinduet lukker det
            pygame.quit()
        if event.type == pygame.MOUSEBUTTONDOWN: # Hvis museknappen er nede
            if rect_singleplayer.collidepoint(event.pos): # "Hvis singleplayer knappen kolliderer med punktet der spilleren klikket"
                main_menu = False
                singleplayer = True
                multiplayer = False
            elif rect_multiplayer.collidepoint(event.pos): # "Hvis multiplayer knappen kolliderer med punktet der spilleren klikket"
                main_menu = False
                multiplayer = True
                singleplayer = False
 
    pygame.draw.rect(screen, ORANGE, rect_singleplayer, 3) # Tegne begge rektangelene for singleplayer og multiplayer knappene
    pygame.draw.rect(screen, ORANGE, rect_multiplayer, 3)
    text_single_surface = font.render(text_single, True, WHITE) # Rendere, så definere posisjonen, så tegne singleplayer teksten
    text_single_rect = text_single_surface.get_rect(center=rect_singleplayer.center)
    screen.blit(text_single_surface, text_single_rect)
    text_multi_surface = font.render(text_multi, True, WHITE) # Rendere, så definere posisjonen, så tegne multiplayer teksten
    text_multi_rect = text_multi_surface.get_rect(center=rect_multiplayer.center)
    screen.blit(text_multi_surface, text_multi_rect)
    pygame.display.set_caption(f"Sjakk - {status}")
    pygame.display.flip()
    clock.tick(60)
 
if singleplayer:
    print("Gamemode: Singleplayer") # Debugging
    status = "Singleplayer" # Sette status for
    script_dir = os.path.dirname(os.path.abspath(__file__))
    x_path = os.path.join(script_dir, "media", "x.png")
    fullscreen_path = os.path.join(script_dir, "media", "fullscreen.png")
    grid_path = os.path.join(script_dir, "media", "grid.png")
    if is_fullscreen: # Finne ut av hvor stor skjermen er så jeg kan bruke rett størrelse for selve grid'en
        filler_variable, grid_image_size_y = screen.get_size() # litt ueffektivt men det virker
        grid_image_size = (grid_image_size_y, grid_image_size_y)
    else:  
        grid_image_size = (HEIGHT, HEIGHT) # Hvis fullscreen ikke har bitt skrudd på, kommer størrelsen alltid å være 800, 500
        pygame.display.set_mode((800, 500))
    grid_rect = pygame.rect.Rect(0, 0, *grid_image_size) # Definere en rektangel som inneholder gridd'en og ekstra innholdet til høyre
    content_rect = pygame.rect.Rect(HEIGHT, 0, (WIDTH - HEIGHT), HEIGHT)
    grid_image_size_y = HEIGHT # trengs for senere under matrix.get_blit_pos
 
    class matrix: # min metode for å lagre og endre posisjonen til alle brikkene
        def __init__(self):
                self.board_matrix = [
                    ["black_rook", "black_knight", "black_bishop", "black_queen", "black_king", "black_bishop", "black_knight", "black_rook"],
                    ["black_pawn", "black_pawn", "black_pawn", "black_pawn", "black_pawn", "black_pawn", "black_pawn", "black_pawn", ],
                    ["empty", "empty", "empty", "empty", "empty", "empty", "empty", "empty"],
                    ["empty", "empty", "empty", "empty", "empty", "empty", "empty", "empty"],
                    ["empty", "empty", "empty", "empty", "empty", "empty", "empty", "empty"],
                    ["empty", "empty", "empty", "empty", "empty", "empty", "empty", "empty"],
                    ["white_pawn", "white_pawn", "white_pawn", "white_pawn", "white_pawn", "white_pawn", "white_pawn", "white_pawn", ],
                    ["white_rook", "white_knight", "white_bishop", "white_queen", "white_king", "white_bishop", "white_knight", "white_rook"],
                ] # Posisjonen til alle brikkene
       
        def __iter__(self): # Vise hvordan man skal få tilgang til data i spesifikke posisjoner i matrix'en
            for row in self.board_matrix:
                for piece in row:
                    yield piece
 
        @staticmethod # Static method betyr bare at selve funkjsonen ikke trenger tilgang til instance'et, altså "self.board_matrix", og viser at funksjonen er selvstendig
        def get_blit_pos(x, y): # Finne ut av hvor jeg skal plassere alle brikkene på skjermen
            column = ((x * 2.18) * 62.5 - 5) * (grid_image_size_y / 1080)
            row = ((y * 2.18) * 62.5 - 5) * (grid_image_size_y / 1080)
            return column, row
 
        @staticmethod
        def get_tile(x,y): # Finne ut hvilket rute spilleren har klikket
            tile_size = grid_image_size_y / 8
            column = int(x // tile_size)
            row = int(y // tile_size)
            print("tile2: ", row, column)
            if column > 7 or row > 7:
                return False
            elif column < 0 or row < 0:
                return False
            print("I think row and column is ", row, column)
            return row, column
       
        @staticmethod
        def get_piece_item(piece): # Et dictionary for å hente frem bilde elementene fra string
            try:
            # map piece name -> image global
                mapping = {
                    "black_rook": black_rook_image.copy(), # type: ignore
                    "black_knight": black_knight_image.copy(), # type: ignore
                    "black_bishop": black_bishop_image.copy(), # type: ignore
                    "black_king": black_king_image.copy(), # type: ignore
                    "black_queen": black_queen_image.copy(), # type: ignore
                    "black_pawn": black_pawn_image.copy(), # type: ignore
                    "white_rook": white_rook_image.copy(), # type: ignore
                    "white_knight": white_knight_image.copy(), # type: ignore
                    "white_bishop": white_bishop_image.copy(), # type: ignore
                    "white_king": white_king_image.copy(), # type: ignore
                    "white_queen": white_queen_image.copy(), # type: ignore
                    "white_pawn": white_pawn_image.copy(), # type: ignore
                }
            except NameError: # Error
                raise RuntimeError("Piece images are not loaded. Call matrix.load() before calling get_piece_item().")
 
            if piece == "empty" or piece is None: # Hvis brikken er "ingenting" så returner ingenting
                return None
 
            img = mapping.get(piece) # Hvis man ikke kan finne bildet fra brikke strengen
            if img is None:
                a = type(piece)
                raise KeyError(f"get_piece_item: unknown piece '{piece}', obj '{a}'")
            return img.copy()
 
        @staticmethod
        def load(): # Brukes for å laste inn alle bildene til den korrekte størrelsen
            script_dir = os.path.dirname(os.path.abspath(__file__)) # Definere hvor bilde filene ligger
            pieces_dir = os.path.join(script_dir, "media", "pieces")
 
            # Laste inn alle bildene
            black_pawn_image = pygame.image.load(os.path.join(pieces_dir, "black-pawn.png")).convert_alpha()
            black_rook_image = pygame.image.load(os.path.join(pieces_dir, "black-rook.png")).convert_alpha()
            black_knight_image = pygame.image.load(os.path.join(pieces_dir, "black-knight.png")).convert_alpha()
            black_bishop_image = pygame.image.load(os.path.join(pieces_dir, "black-bishop.png")).convert_alpha()
            black_queen_image = pygame.image.load(os.path.join(pieces_dir, "black-queen.png")).convert_alpha()
            black_king_image = pygame.image.load(os.path.join(pieces_dir, "black-king.png")).convert_alpha()
 
            white_pawn_image = pygame.image.load(os.path.join(pieces_dir, "white-pawn.png")).convert_alpha()
            white_rook_image = pygame.image.load(os.path.join(pieces_dir, "white-rook.png")).convert_alpha()
            white_knight_image = pygame.image.load(os.path.join(pieces_dir, "white-knight.png")).convert_alpha()
            white_bishop_image = pygame.image.load(os.path.join(pieces_dir, "white-bishop.png")).convert_alpha()
            white_queen_image = pygame.image.load(os.path.join(pieces_dir, "white-queen.png")).convert_alpha()
            white_king_image = pygame.image.load(os.path.join(pieces_dir, "white-king.png")).convert_alpha()
 
            scale_ratio = grid_image_size[0] / 1080  # Sammenligne det nåverdige brettet med 1080 så jeg kan skalere brikkene etter brettet
 
            def resize(img):
                w, h = img.get_size() # width, height = størrelse til target bilde
                return pygame.transform.smoothscale(img, (int(w * scale_ratio), int(h * scale_ratio))) # S m o o t h  s c a l e
 
            globals().update({ # Oppdatere globale variabler til de nye skalerte versjonene
                "black_pawn_image": resize(black_pawn_image),
                "black_rook_image": resize(black_rook_image),
                "black_knight_image": resize(black_knight_image),
                "black_bishop_image": resize(black_bishop_image),
                "black_queen_image": resize(black_queen_image),
                "black_king_image": resize(black_king_image),
 
                "white_pawn_image": resize(white_pawn_image),
                "white_rook_image": resize(white_rook_image),
                "white_knight_image": resize(white_knight_image),
                "white_bishop_image": resize(white_bishop_image),
                "white_queen_image": resize(white_queen_image),
                "white_king_image": resize(white_king_image),
            })
 
        def drop_piece(self, row, column, piece): # Funksjon for å sleppe en brikke på matrixen
            self.board_matrix[row][column] = piece
           
        def is_empty(self, row, column): # Hvis en rute er tom, altså ikke None men "empty"
            if self.board_matrix[row][column] == "empty":
                return True
            else:
                return False
   
    def fullscreen(): # Gjøre skjermen til fullskjerm
        global is_fullscreen
        if is_fullscreen:
            print("its already fullscreen")
        else:
            global screen
            import ctypes
            user32 = ctypes.windll.user32 # Bruker disse fire OS komandoene for å finne breddn oh øyden
            user32.SetProcessDPIAware()  
            screen_width = user32.GetSystemMetrics(0)
            screen_height = user32.GetSystemMetrics(1)
            screen = pygame.display.set_mode((screen_width, screen_height))
            global grid_image_size # Må alle være globals så de kan brukes utenfor funksjonen
            global grid_image_size_x
            global grid_image_size_y
            grid_image_size_x, grid_image_size_y = screen.get_size() # Finne størrelsen som brettet bør være etter
            grid_image_size = (grid_image_size_y, grid_image_size_y)
            is_fullscreen = True
            global exit_button_rect
            global fullscreen_button_rect
            exit_button_rect = pygame.rect.Rect((grid_image_size_x - 75, 25), (50, 50)) # Sette ny størrelse til fullscreen og exit knappen, i tilleg tilk å laste inn de nye brikkene ved å kalle "load" funksjonen
            fullscreen_button_rect = pygame.rect.Rect((grid_image_size_x - 150, 25), (50, 50))
            matrix.load()
            exit_button_rect = pygame.rect.Rect((screen_width - 75, 25), (50, 50))
            fullscreen_button_rect = pygame.rect.Rect((screen_width - 150, 25), (50, 50))
            print("fullscreen: ", is_fullscreen)
 
    def windowed(): # Gjør skjermen fra fullskjerm til vindu modus
        global is_fullscreen
        if not is_fullscreen:
            print("its already windowed")
        else:
            global screen
            screen = pygame.display.set_mode((800, 500), pygame.RESIZABLE)
            global grid_image_size # Må definere alle tingene som globals fordi python antar at alle variabler laget innenfor en funksjon er lokale til funksjonen
            global grid_image_size_y
            global grid_image_size_x
            grid_image_size = (500, 500)
            grid_image_size_x, grid_image_size_y = 500, 500
            is_fullscreen = False
            global exit_button_rect
            global fullscreen_button_rect
            exit_button_rect = pygame.rect.Rect((425, 25), (50, 50)) # Redefinere exit og fullscreen knappene i tilleg til å kalle for "load" funksjonen igjen
            fullscreen_button_rect = pygame.rect.Rect((350, 25), (50, 50))
            matrix.load()
            exit_button_rect = pygame.rect.Rect((725, 25), (50, 50))
            fullscreen_button_rect = pygame.rect.Rect((650, 25), (50, 50))
            print("fullscreen: ", is_fullscreen)
 
    if is_fullscreen:
        exit_button_rect = pygame.rect.Rect((WIDTH - 75, 25), (50, 50))
        fullscreen_button_rect = pygame.rect.Rect((WIDTH - 150, 25), (50, 50))
    else:
        exit_button_rect = pygame.rect.Rect((725, 25), (50, 50))
        fullscreen_button_rect = pygame.rect.Rect((650, 25), (50, 50))
 
    m = matrix() # Lage matrixen
    piece = ""
    dragging = False
    blit_drag_piece = False
 
if multiplayer:
    print("Multiplayer")
    status = "Multiplayer"
 
while singleplayer:
    prev_matrix = m
    screen.fill(BLACK)
    matrix.load()
    for event in pygame.event.get(): # Sjekke inputt fra spilleren, og bruke det til ting som å lukke programmet når det signaliseres.
        if event.type == pygame.QUIT: # Hvis vi trykker X'en på pygame vinduet lukker det
            pygame.quit()
        elif event.type == pygame.MOUSEBUTTONDOWN: # Hvis musen trykkes ned
            print("mousedown")
            counter = 0
            mouse_x, mouse_y = event.pos
 
            if exit_button_rect.collidepoint(event.pos): # Sjekke først om musen trykket pp exit eller fullscreen knappene
                print("Exit button pressed")
                pygame.quit()
 
            elif fullscreen_button_rect.collidepoint(event.pos):
                print("Fullscreen button pressed")
                if not is_fullscreen:
                    fullscreen()
                else:
                    windowed()
 
            else: # Hvis du trykker innenfor bordet
                tile = matrix.get_tile(mouse_x, mouse_y)
                if not tile: # Logikken gjøres sånt fordi "matrix.get_tile" returnerer False hvis musen er utenfor brettet, så logikken blir "if not False" som er det samme som "if True"
                    print("Clicked outside board --> ignoring")
                    dragging = False
                    piece = None
                    continue
 
                row, column = tile
                print(f"Clicked tile: ({row}, {column})")
 
                if m.is_empty(row, column): # Hvis ruten er tom
                    print("Empty square clicked --> not dragging")
                    dragging = False
                    piece = None
                    continue
 
                piece = m.board_matrix[row][column] # Fange opp brikken der du trykket
                print(f"Piece selected: {piece} at ({row}, {column})")
                dragging = True
                m.board_matrix[row][column] = "empty" # Sette plassen til tomt så du ikke bare dupliserte brikken
                piece_previousSpot = (row, column) # I tilfelle noe gale skjer så brikken kan gå tilbake til der den opprinnelig var
                piece_previous = piece
                counter += 1
 
                print(f"dragging: {dragging}, piece={piece}, counter={counter}") # Debug
           
        elif event.type == pygame.MOUSEBUTTONUP: # Hvis museknappen sleppes
            if counter == 1: # Kode som bare kjøres én gang
                print("dragging: false")
                dragging = False
                mouse_x, mouse_y = event.pos
                try: # Prøve å kjøre kode, og kjøre noen annen kode hvis en feilmelding oppstår
                    row, column = matrix.get_tile(mouse_x, mouse_y) # Finne rute
                    print("a") # Debug
                    if m.is_empty(row, column) == True: # Hvis en plass er tom
                        print("piece moved") # Debug
                        m.drop_piece(row, column, piece) # sleppe brikken
                    else:
                        print(piece) # Mer debug
                        print("piece taken")
                        m.drop_piece(row, column, piece) # Sleppe brikken
                except Exception as err: # Hvis det oppstår en feil, i tilleg til å lagre hva den feilen var til debugging
                    print("invalid move spot, error code:", err)
                    row, column = piece_previousSpot # Sleppe brikken tilbake til der den var før feilmeldingen oppsto
                    m.board_matrix[row][column] = piece_previous
                finally: # Til slutt
                    piece = None
                    piece_previous = None
                    piece_previousSpot = None
                    counter = 0
 
    info = pygame.display.Info()
    WIDTH, HEIGHT = info.current_w, info.current_h
    import ctypes
    user32 = ctypes.windll.user32 # Bruker disse fire OS komandoene for å finne breddn oh øyden
    user32.SetProcessDPIAware()  
    screen_width = user32.GetSystemMetrics(0)
    screen_height = user32.GetSystemMetrics(1)
    if is_fullscreen == False:
        if (WIDTH, HEIGHT) != (800, 500):
            fullscreen()
    elif is_fullscreen == True:
        if (WIDTH, HEIGHT) != (screen_width, screen_height):
            windowed()
 
    grid_image = pygame.image.load(grid_path).convert() # Vise brettet
    grid_image = pygame.transform.scale(grid_image, grid_image_size)
    screen.blit(grid_image, (0, 0))
 
    exit_button_image = pygame.image.load(x_path).convert_alpha() # laste inn begge knappene for fullscreen og exit
    exit_button_image = pygame.transform.scale(exit_button_image, (50, 50))
    screen.blit(exit_button_image, exit_button_rect)
    fullscreen_button_image = pygame.image.load(fullscreen_path).convert_alpha()
    fullscreen_button_image = pygame.transform.scale(fullscreen_button_image, (50, 50))
    screen.blit(fullscreen_button_image, fullscreen_button_rect)    
 
    column = 0
    calc_row = 0
    for row_index, row in enumerate(m.board_matrix): # Vise alle brikkene hvor enn matrixen mener de er
        for col_index, piece_ in enumerate(row):
            if piece_ == "empty":
                continue
            elif piece_ == "black_rook":
                screen.blit(black_rook_image.copy(), matrix.get_blit_pos(col_index, row_index))
            elif piece_ == "black_knight":
                screen.blit(black_knight_image.copy(), matrix.get_blit_pos(col_index, row_index))
            elif piece_ == "black_bishop":
                screen.blit(black_bishop_image.copy(), matrix.get_blit_pos(col_index, row_index))
            elif piece_ == "black_king":
                screen.blit(black_king_image.copy(), matrix.get_blit_pos(col_index, row_index))
            elif piece_ == "black_queen":
                screen.blit(black_queen_image.copy(), matrix.get_blit_pos(col_index, row_index))
            elif piece_ == "black_pawn":
                screen.blit(black_pawn_image.copy(), matrix.get_blit_pos(col_index, row_index))
            elif piece_ == "white_rook":
                screen.blit(white_rook_image.copy(), matrix.get_blit_pos(col_index, row_index))
            elif piece_ == "white_knight":
                screen.blit(white_knight_image.copy(), matrix.get_blit_pos(col_index, row_index))
            elif piece_ == "white_bishop":
                screen.blit(white_bishop_image.copy(), matrix.get_blit_pos(col_index, row_index))
            elif piece_ == "white_king":
                screen.blit(white_king_image.copy(), matrix.get_blit_pos(col_index, row_index))
            elif piece_ == "white_queen":
                screen.blit(white_queen_image.copy(), matrix.get_blit_pos(col_index, row_index))
            elif piece_ == "white_pawn":
                screen.blit(white_pawn_image.copy(), matrix.get_blit_pos(col_index, row_index))
       
        column += 1 # Trengs fordi ellers hadde alle brikkene blitt tegnet på samme plass
        if column == 8:
            column = 0
            calc_row += 1
        if calc_row == 8:
            break
 
    if dragging and piece not in (None, "empty"): # "hvis noe dras og brikken ikke er 'ingenting' eller None"
        piece_img = matrix.get_piece_item(piece) # Få bildet
        if piece_img is not None: # Hvis den ikke er ingenting
            mouse_x, mouse_y = pygame.mouse.get_pos()
            screen.blit(piece_img, (mouse_x - 30, mouse_y - 30))
            print("debug1: ", type(matrix.get_piece_item(piece))) # for debugging
            print("mousex: ", mouse_x, "mousey: ", mouse_y, "grid_size_y: ", grid_image_size_y, "piece: ", piece) # debug
        else:
            print(matrix.get_piece_item(piece), "", piece, " блят...")
 
    pygame.display.set_caption(f"Sjakk - {status}") # Sette statuset for spiller på tittelen til spillet
    pygame.display.flip()
    clock.tick(60)
 
import time
time.sleep(2)