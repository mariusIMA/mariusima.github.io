import os
import sys
import subprocess
import json

script_dir = os.path.dirname(os.path.abspath(__file__))
script_path = os.path.join(script_dir, "log.txt")
json_dir = os.path.join(script_dir, "spilt_før.json")
SPILLDATA = json_dir

with open(script_path,"a") as file_object:
    file_object.write("pygame init \n")

# Sjekk og installer pygame
try:
    import pygame
except ImportError:
    print("Pygame ikke funnet. Installerer...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pygame"])
    import pygame

with open(script_path,"a") as file_object:
    file_object.write("installer done\n")

# Sjekk om brukeren har spilt før
def har_spilt_før():
    return os.path.exists(SPILLDATA)

with open(script_path,"a") as file_object:
    file_object.write("har spilt før\n")

# Marker at brukeren har spilt
def merk_som_spilt():
    with open(SPILLDATA, "w") as f:
        json.dump({"har_spilt": True}, f)

with open(script_path,"a") as file_object:
    file_object.write("merk som spilt\n")

# Kjør oppsett
import time
if not har_spilt_før():
    print("Velkommen! Første gang du spiller.")
    merk_som_spilt()
else:
    print("Velkommen tilbake! Det er ingen poeng i å åpne dette programmet med mindre du vil re-installere noe som du vet du har avinstallert.")
print("Skriv inn ja for å åpne sjakk, ellers skriv noe annet.")


with open(script_path,"a") as file_object:
    file_object.write("json done\n")

import subprocess
import sys

# Fil lokasjon til sjakk.py
script_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(script_dir)
script_path = os.path.join(parent_dir, "sjakk.py")

# Debug prints
print(f"Launching script at: {script_path}")
print(f"Python executable: {sys.executable}")
print(f"File exists: {os.path.exists(json_dir)}")

# Launche den andre scripten
subprocess.Popen([sys.executable, script_path])

# Lukke denne scripten etter jeg har spilt av installereren
sys.exit(0)